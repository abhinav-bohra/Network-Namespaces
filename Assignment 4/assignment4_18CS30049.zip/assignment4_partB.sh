#!/bin/bash
#---------------------------------------------------------------------------------

# Course CS39006: Networks Lab
# Assignment 4  : Network Namespace and Routes - PART B
# Name          : Abhinav Bohra
# Roll No.      : 18CS30049

#---------------------------------------------------------------------------------
# Create network namespaces
sudo ip netns add H1
sudo ip netns add H2
sudo ip netns add H3
sudo ip netns add H4
sudo ip netns add R1
sudo ip netns add R2
sudo ip netns add R3

#---------------------------------------------------------------------------------
# Create the pair of Virtual interfaces 
sudo ip link add v1 type veth peer name v2
sudo ip link add v3 type veth peer name v4
sudo ip link add v5 type veth peer name v6
sudo ip link add v7 type veth peer name v8
sudo ip link add v9 type veth peer name v10
sudo ip link add v11 type veth peer name v12

#---------------------------------------------------------------------------------
# Assign each virtual interface to respective network namespace
sudo ip link set v1 netns H1
sudo ip link set v2 netns R1
sudo ip link set v3 netns H2
sudo ip link set v4 netns R1
sudo ip link set v5 netns R1
sudo ip link set v6 netns R2
sudo ip link set v7 netns R2
sudo ip link set v8 netns R3
sudo ip link set v9 netns R3
sudo ip link set v10 netns H3
sudo ip link set v11 netns R3
sudo ip link set v12 netns H4

#---------------------------------------------------------------------------------
# Assign the IP address to interfaces
sudo ip -n H1 addr add 10.0.10.49 dev v1
sudo ip -n R1 addr add 10.0.10.50 dev v2
sudo ip -n H2 addr add 10.0.20.49 dev v3
sudo ip -n R1 addr add 10.0.20.50 dev v4
sudo ip -n R1 addr add 10.0.30.49 dev v5
sudo ip -n R2 addr add 10.0.30.50 dev v6
sudo ip -n R2 addr add 10.0.40.49 dev v7
sudo ip -n R3 addr add 10.0.40.50 dev v8
sudo ip -n R3 addr add 10.0.50.49 dev v9
sudo ip -n H3 addr add 10.0.50.50 dev v10
sudo ip -n R3 addr add 10.0.60.49 dev v11
sudo ip -n H4 addr add 10.0.60.50 dev v12

#---------------------------------------------------------------------------------
# Bring up the virtual interfaces
sudo ip -n H1 link set dev v1 up
sudo ip -n R1 link set dev v2 up
sudo ip -n H2 link set dev v3 up
sudo ip -n R1 link set dev v4 up
sudo ip -n R1 link set dev v5 up
sudo ip -n R2 link set dev v6 up
sudo ip -n R2 link set dev v7 up
sudo ip -n R3 link set dev v8 up
sudo ip -n R3 link set dev v9 up
sudo ip -n H3 link set dev v10 up
sudo ip -n R3 link set dev v11 up
sudo ip -n H4 link set dev v12 up

# Bring up the loopback interface
sudo ip -n H1 link set lo up 
sudo ip -n H2 link set lo up 
sudo ip -n H3 link set lo up 
sudo ip -n H4 link set lo up 
sudo ip -n R1 link set lo up 
sudo ip -n R2 link set lo up 
sudo ip -n R3 link set lo up 

#---------------------------------------------------------------------------------
# Routing between veth pairs (v1-v2, v3-v4, v5-v6, V7-V8, V9-V10, V11-V12)
sudo ip -n H1 route add 10.0.10.50 dev v1
sudo ip -n R1 route add 10.0.10.49 dev v2

sudo ip -n H2 route add 10.0.20.50 dev v3
sudo ip -n R1 route add 10.0.20.49 dev v4

sudo ip -n R1 route add 10.0.30.50 dev v5
sudo ip -n R2 route add 10.0.30.49 dev v6

sudo ip -n R2 route add 10.0.40.50 dev v7
sudo ip -n R3 route add 10.0.40.49 dev v8

sudo ip -n R3 route add 10.0.50.50 dev v9
sudo ip -n H3 route add 10.0.50.49 dev v10

sudo ip -n R3 route add 10.0.60.50 dev v11
sudo ip -n H4 route add 10.0.60.49 dev v12

#---------------------------------------------------------------------------------
#Adding routes for hops
sudo ip netns exec H1 ip route add 10.0.20.0/24 via 10.0.10.50 dev v1
sudo ip netns exec H1 ip route add 10.0.30.0/24 via 10.0.10.50 dev v1
sudo ip netns exec H1 ip route add 10.0.40.0/24 via 10.0.10.50 dev v1
sudo ip netns exec H1 ip route add 10.0.50.0/24 via 10.0.10.50 dev v1
sudo ip netns exec H1 ip route add 10.0.60.0/24 via 10.0.10.50 dev v1

sudo ip netns exec H2 ip route add 10.0.10.0/24 via 10.0.20.50 dev v3
sudo ip netns exec H2 ip route add 10.0.30.0/24 via 10.0.20.50 dev v3
sudo ip netns exec H2 ip route add 10.0.40.0/24 via 10.0.20.50 dev v3
sudo ip netns exec H2 ip route add 10.0.50.0/24 via 10.0.20.50 dev v3
sudo ip netns exec H2 ip route add 10.0.60.0/24 via 10.0.20.50 dev v3

sudo ip netns exec R1 ip route add 10.0.40.0/24 via 10.0.30.50 dev v5
sudo ip netns exec R1 ip route add 10.0.50.0/24 via 10.0.30.50 dev v5
sudo ip netns exec R1 ip route add 10.0.60.0/24 via 10.0.30.50 dev v5

sudo ip netns exec R2 ip route add 10.0.10.0/24 via 10.0.30.49 dev v6
sudo ip netns exec R2 ip route add 10.0.20.0/24 via 10.0.30.49 dev v6
sudo ip netns exec R2 ip route add 10.0.50.0/24 via 10.0.40.50 dev v7
sudo ip netns exec R2 ip route add 10.0.60.0/24 via 10.0.40.50 dev v7

sudo ip netns exec R3 ip route add 10.0.10.0/24 via 10.0.40.49 dev v8
sudo ip netns exec R3 ip route add 10.0.20.0/24 via 10.0.40.49 dev v8
sudo ip netns exec R3 ip route add 10.0.30.0/24 via 10.0.40.49 dev v8

sudo ip netns exec H3 ip route add 10.0.10.0/24 via 10.0.50.49 dev v10
sudo ip netns exec H3 ip route add 10.0.20.0/24 via 10.0.50.49 dev v10
sudo ip netns exec H3 ip route add 10.0.30.0/24 via 10.0.50.49 dev v10
sudo ip netns exec H3 ip route add 10.0.40.0/24 via 10.0.50.49 dev v10
sudo ip netns exec H3 ip route add 10.0.60.0/24 via 10.0.50.49 dev v10 

sudo ip netns exec H4 ip route add 10.0.10.0/24 via 10.0.60.49 dev v12
sudo ip netns exec H4 ip route add 10.0.20.0/24 via 10.0.60.49 dev v12 
sudo ip netns exec H4 ip route add 10.0.30.0/24 via 10.0.60.49 dev v12
sudo ip netns exec H4 ip route add 10.0.40.0/24 via 10.0.60.49 dev v12
sudo ip netns exec H4 ip route add 10.0.50.0/24 via 10.0.60.49 dev v12

#---------------------------------------------------------------------------------
#Enabling IP Forwarding

# Declare an array storing all namespaces
declare -a arr=("H1" "H2" "H3" "H4" "R1" "R2" "R3")

for i in "${arr[@]}"
do
	sudo ip netns exec "$i" sysctl -w net.ipv4.ip_forward=1
done

#---------------------------------------------------------------------------------
# Pinging
echo -e "\nTesting Pings"

for ns in "${arr[@]}"
do
   	echo -e "\nTesiting pings from "$ns":-\n"
   	a=1
   	while [ $a -le 6 ]
   	do
		b=$((a*10))
		sudo ip netns exec "$ns" ping -c3 10.0."$b".49 
		sudo ip netns exec "$ns" ping -c3 10.0."$b".50 
		a=$((a+1))
   	done
done
#---------------------------------------------------------------------------------
#Traceroutes
sudo ip netns exec H1 traceroute 10.0.60.50 #H1->H4
sleep 2
sudo ip netns exec H3 traceroute 10.0.60.50 #H3->H4
sleep 2
sudo ip netns exec H4 traceroute 10.0.20.49 #H4->H2
