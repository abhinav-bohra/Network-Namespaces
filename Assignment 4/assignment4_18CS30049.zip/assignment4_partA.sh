#!/bin/bash
#---------------------------------------------------------------------------------

# Course CS39006: Networks Lab
# Assignment 4  : Network Namespace and Routes - PART A
# Name          : Abhinav Bohra
# Roll No.      : 18CS30049

#---------------------------------------------------------------------------------
# Create network namespaces
sudo ip netns add N1
sudo ip netns add N2
sudo ip netns add N3
sudo ip netns add N4

#---------------------------------------------------------------------------------
# Create the pair of Virtual interfaces 
sudo ip link add v1 type veth peer name v2
sudo ip link add v3 type veth peer name v4
sudo ip link add v5 type veth peer name v6

#---------------------------------------------------------------------------------
# Assign each virtual interface to respective network namespace
sudo ip link set v1 netns N1
sudo ip link set v2 netns N2
sudo ip link set v3 netns N2
sudo ip link set v4 netns N3
sudo ip link set v5 netns N3
sudo ip link set v6 netns N4

#---------------------------------------------------------------------------------
# Assign the IP address to interfaces
sudo ip -n N1 addr add 10.0.10.49 dev v1
sudo ip -n N2 addr add 10.0.10.50 dev v2
sudo ip -n N2 addr add 10.0.20.49 dev v3
sudo ip -n N3 addr add 10.0.20.50 dev v4
sudo ip -n N3 addr add 10.0.30.49 dev v5
sudo ip -n N4 addr add 10.0.30.50 dev v6

#---------------------------------------------------------------------------------
# Bring up the virtual interfaces
sudo ip -n N1 link set dev v1 up
sudo ip -n N2 link set dev v2 up
sudo ip -n N2 link set dev v3 up
sudo ip -n N3 link set dev v4 up
sudo ip -n N3 link set dev v5 up
sudo ip -n N4 link set dev v6 up

# Bring up the loopback interface
sudo ip -n N1 link set lo up 
sudo ip -n N2 link set lo up 
sudo ip -n N3 link set lo up 
sudo ip -n N4 link set lo up 

#---------------------------------------------------------------------------------
# Routing between veth pairs (v1-v2, v3-v4, v5-v6)
sudo ip -n N1 route add 10.0.10.50 dev v1
sudo ip -n N2 route add 10.0.10.49 dev v2
sudo ip -n N2 route add 10.0.20.50 dev v3
sudo ip -n N3 route add 10.0.20.49 dev v4
sudo ip -n N3 route add 10.0.30.50 dev v5
sudo ip -n N4 route add 10.0.30.49 dev v6

#Adding routes
sudo ip netns exec N2 ip route add 10.0.30.0/24 via 10.0.20.50 dev v3 #For 10.0.30.0/24 from N2 
sudo ip netns exec N4 ip route add 10.0.20.0/24 via 10.0.30.49 dev v6 #For 10.0.20.0/24 from N4
sudo ip netns exec N3 ip route add 10.0.10.0/24 via 10.0.20.49 dev v4 #For 10.0.10.0/24 from N3 
sudo ip netns exec N1 ip route add 10.0.20.0/24 via 10.0.10.50 dev v1 #For 10.0.20.0/24 from N1
sudo ip netns exec N4 ip route add 10.0.10.0/24 via 10.0.30.49 dev v6 #For 10.0.10.0/24 from N4
sudo ip netns exec N1 ip route add 10.0.30.0/24 via 10.0.10.50 dev v1 #For 10.0.30.0/24 from N1

#---------------------------------------------------------------------------------
# Enable IP forwarding
sudo sysctl -w net.ipv4.ip_forward=1

#---------------------------------------------------------------------------------
# Pinging
echo -e "\nTesting Pings"

i=1
while [ $i -le 4 ];
do
	echo -e "\nTesting Pings from N"$i" :-\n"
	sudo ip netns exec N"$i" ping -c3 10.0.10.49
	sudo ip netns exec N"$i" ping -c3 10.0.10.50
	sudo ip netns exec N"$i" ping -c3 10.0.20.49
	sudo ip netns exec N"$i" ping -c3 10.0.20.50
	sudo ip netns exec N"$i" ping -c3 10.0.30.49
	sudo ip netns exec N"$i" ping -c3 10.0.30.50

	i=$((i+1))
done
#---------------------------------------------------------------------------------

