#!/bin/bash
#---------------------------------------------------------------------------------

# Course CS39006: Networks Lab
# Assignment 3  : Network Namespace and Ethernet Bridge - PART A
# Name          : Abhinav Bohra
# Roll No.      : 18CS30049

#---------------------------------------------------------------------------------
# Create the ns0 network namespace
sudo ip netns add ns0

# Create the ns1 network namespace
sudo ip netns add ns1

#---------------------------------------------------------------------------------
# Create the pair of veth interfaces named, veth0 and veth1
sudo ip link add veth0 type veth peer name veth1

# Assign the veth0 interface to the ns0 network namespace
sudo ip link set veth0 netns ns0

# Assign the veth1 interface to the ns1 network namespace
sudo ip link set veth1 netns ns1

#---------------------------------------------------------------------------------
# Assign the 10.1.1.0/24 IP address range to the veth0 interface
sudo ip -n ns0 addr add 10.1.1.0/24 dev veth0

# Assign the 10.1.2.0/24 IP address range to the veth0 interface
sudo ip -n ns1 addr add 10.1.2.0/24 dev veth1

#---------------------------------------------------------------------------------
# Bring up the veth0 interface
sudo ip -n ns0 link set dev veth0 up

# Bring up the veth1 interface
sudo ip -n ns1 link set dev veth1 up

# Bring up the lo interface, because packets destined for 10.1.1.0/24
sudo ip -n ns0 link set lo up 

# Bring up the lo interface, because packets destined for 10.1.2.0/24
sudo ip -n ns1 link set lo up 

#---------------------------------------------------------------------------------
# Routing the veth0
sudo ip -n ns0 route add 10.1.2.0/24 dev veth0

# Routing the veth1
sudo ip -n ns1 route add 10.1.1.0/24 dev veth1

#---------------------------------------------------------------------------------
