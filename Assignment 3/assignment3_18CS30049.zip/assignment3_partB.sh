#!/bin/bash
#---------------------------------------------------------------------------------

# Course CS39006: Networks Lab
# Assignment 3  : Network Namespace and Ethernet Bridge - PART B
# Name          : Abhinav Bohra
# Roll No.      : 18CS30049

#---------------------------------------------------------------------------------
# CREATING NETWORK NAMESPACES

# Create the H1 network namespace
sudo ip netns add H1

# Create the H2 network namespace
sudo ip netns add H2

# Create the H3 network namespace
sudo ip netns add H3

# Create the R network namespace
sudo ip netns add R

#---------------------------------------------------------------------------------
# CREATING VIRTUAL ETHERNET INTERFACES 

# Create the pair of veth interfaces named, veth1 and veth2
sudo ip link add veth1 type veth peer name veth2

# Create the pair of veth interfaces named, veth3 and veth6
sudo ip link add veth3 type veth peer name veth6

# Create the pair of veth interfaces named, veth4 and veth5
sudo ip link add veth4 type veth peer name veth5

#---------------------------------------------------------------------------------
# ASSIGNING VIRTUAL ETHERNET INTERFACES TO BRIDGE AND NETWORK NAMESPACES

# Assign the veth1 interface to the H1 network namespace
sudo ip link set veth1 netns H1

# Assign the veth2 interface to the R network namespace
sudo ip link set veth2 netns R

# Assign the veth3 interface to the R network namespace
sudo ip link set veth3 netns R

# Assign the veth4 interface to the R network namespace
sudo ip link set veth4 netns R

# Assign the veth5 interface to the H3 network namespace
sudo ip link set veth5 netns H3

# Assign the veth6 interface to the H2 network namespace
sudo ip link set veth6 netns H2

#---------------------------------------------------------------------------------
# ASSIGNING VIRTUAL ETHERNET INTERFACES TO BRIDGE AND NETWORK NAMESPACES

# Assign the 10.0.10.49/24 IP address range to the veth1 interface
sudo ip -n H1 addr add 10.0.10.49/24 dev veth1

# Assign the 10.0.10.1/24 IP address range to the veth2 interface
sudo ip -n R addr add 10.0.10.1/24 dev veth2

# Assign the 10.0.20.1/24 IP address range to the veth3 interface
sudo ip -n R addr add 10.0.20.1/24 dev veth3

# Assign the 10.0.30.1/24 IP address range to the veth4 interface
sudo ip -n R addr add 10.0.30.1/24 dev veth4

# Assign the 10.0.30.49/24 IP address range to the veth5 interface
sudo ip -n H3 addr add 10.0.30.49/24 dev veth5

# Assign the 10.0.20.49/24 IP address range to the veth6 interface
sudo ip -n H2 addr add 10.0.20.49/24 dev veth6

#---------------------------------------------------------------------------------
#BRING UP THE VIRTUAL ETHERNET INTERFACES

# Bring up the veth1 interface
sudo ip -n H1 link set dev veth1 up

# Bring up the veth2 interface
sudo ip -n R link set dev veth2 up

# Bring up the veth3 interface
sudo ip -n R link set dev veth3 up

# Bring up the veth4 interface
sudo ip -n R link set dev veth4 up

# Bring up the veth5 interface
sudo ip -n H3 link set dev veth5 up

# Bring up the veth6 interface
sudo ip -n H2 link set dev veth6 up

#---------------------------------------------------------------------------------
#SETTING UP BRIDGE INTERFACE

# Adding BRIDGE bridge to network namespace R
sudo ip netns exec R brctl addbr bridge

# Adding virtual ethernet interfaces veth2, veth3, veth4 to bridge
sudo ip netns exec R brctl addif bridge veth2 veth3 veth4

# Bring up the bridge interface
sudo ip -n R link set dev bridge up

#---------------------------------------------------------------------------------
# ADDING ROUTES

sudo ip -n H1 route add default via 10.0.10.49
sudo ip -n H2 route add default via 10.0.20.49
sudo ip -n H3 route add default via 10.0.30.49
#---------------------------------------------------------------------------------
#ENABLING IP FORWARDING USING sysctl
sudo sysctl -w net.ipv4.ip_forward=1
